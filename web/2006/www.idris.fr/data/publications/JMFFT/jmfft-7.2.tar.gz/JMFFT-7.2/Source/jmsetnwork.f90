! $Header: /home/teuler/cvsroot/lib/jmsetnwork.f90,v 6.2 2000/02/18 17:23:39 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine jmsetnwork(nwork)

  ! Subroutine appelee par l'utilisateur pour augmenter le nwork
  ! des routines 2d et 3d

  implicit none

  ! Arguments
  integer, intent(in) :: nwork

  ! Variables locales
  character(len=*), parameter :: nomsp = 'JMSETNWORK'
  integer :: nwork2

  if (nwork <= 0) then
    call jmerreur1(nomsp,4,nwork)
  end if

  nwork2 = nwork
  call jmgetsetnwork(nwork2,'s')

end subroutine jmsetnwork
