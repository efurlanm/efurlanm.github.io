! $Header: /home/teuler/cvsroot/lib/jmerreur2.f90,v 6.3 2000/03/10 11:57:58 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine jmerreur2(nomsp,code,var1,var2)

  implicit none

  ! Arguments
  character(len=*), intent(in) :: nomsp
  integer, intent(in) :: code
  integer, intent(in) :: var1, var2

  ! Variables locales
  integer :: arret
  character(len=80) :: message

  call jmgetstop(arret)
  if (arret == 1) then
    call jmgetmessage(code,message)
    print *,'JMFFT Erreur dans ',trim(nomsp),' : ',trim(message), &
    & ' (',var1,var2,')'
    stop 1
  else
    call jmsetcode(code)
  end if

end subroutine jmerreur2
