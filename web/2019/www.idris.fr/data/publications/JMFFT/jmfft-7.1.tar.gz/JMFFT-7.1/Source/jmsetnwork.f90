! $Header: /home/teuler/cvsroot/lib/jmsetnwork.f90,v 6.1 1999/10/22 08:35:19 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine jmsetnwork(nwork)

  ! Subroutine appelee par l'utilisateur pour augmenter le nwork
  ! des routines 2d et 3d

  implicit none

  ! Arguments
  integer, intent(in) :: nwork

  ! Variables locales
  character(len=*), parameter :: nomsp = 'JMSETNWORK'

  if (nwork <= 0) then
    call jmerreur1(nomsp,4,nwork)
  end if

  call jmgetsetnwork(nwork,'s')

end subroutine jmsetnwork
