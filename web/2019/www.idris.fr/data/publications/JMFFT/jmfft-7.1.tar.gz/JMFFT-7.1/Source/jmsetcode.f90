! $Header: /home/teuler/cvsroot/lib/jmsetcode.f90,v 6.1 1999/10/22 08:35:19 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine jmsetcode(code)

  implicit none

  ! Argument
  integer, intent(in) :: code

  ! Variables locales

  call jmgetsetcode(code,'s')

end subroutine jmsetcode
