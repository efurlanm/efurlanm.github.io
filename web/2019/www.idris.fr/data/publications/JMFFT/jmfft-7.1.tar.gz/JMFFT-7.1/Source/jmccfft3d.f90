! $Header: /home/teuler/cvsroot/lib/jmccfft3d.f90,v 6.2 1999/10/22 08:50:46 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine ccfft3d(isign,n,m,l,scale,x,ldx1,ldx2,y,ldy1,ldy2,table,work,isys)

  implicit none

  ! Arguments
  integer, intent(in) :: isign
  integer, intent(in) :: n, m, l, ldx1, ldx2, ldy1, ldy2
  real(kind=8), intent(in) :: scale
  real(kind=8), intent(in), dimension(0:2*ldx1-1,0:ldx2-1,0:l-1) :: x
  real(kind=8), intent(out), dimension(0:2*ldy1-1,0:ldy2-1,0:l-1) :: y
  real(kind=8), intent(inout), dimension(0:100+2*(n+m+l)-1) :: table
  real(kind=8), intent(inout), dimension(0:512*max(n,m,l)-1) :: work
  integer, intent(in) :: isys

  ! Variables locales
  integer :: i, j, k
  integer :: ioff
  integer :: ntable, nwork
  integer :: nfact, mfact, lfact
  integer, dimension(0:99) :: fact
  integer :: ideb, ifin, i1, i2, jdeb, jfin, j1, j2, kdeb, kfin, k1, k2
  integer :: nwork_temp, nmtemp, mltemp, nltemp, iwork
  logical :: debut, fini
  character(len=*), parameter :: nomsp = 'CCFFT3D'

  ! Positionnement a 0 du code de retour
  call jmsetcode(0)

  ! Verification des conditions
  if (isign /= 0 .and. isign /=-1 .and. isign /= 1) &
  & call jmerreur1(nomsp,2,isign)
  if (n < 1) call jmerreur1(nomsp,23,n)
  if (m < 1) call jmerreur1(nomsp,21,m)
  if (l < 1) call jmerreur1(nomsp,8,l)
  if (ldx1 < n) call jmerreur2(nomsp,11,ldx1,n)
  if (ldx2 < m) call jmerreur2(nomsp,13,ldx2,m)
  if (ldy1 < n) call jmerreur2(nomsp,17,ldy1,n)
  if (ldy2 < m) call jmerreur2(nomsp,20,ldy2,m)

  ! Gestion de table
  ntable = 100+2*(n+m+l)

  ! Test sur isign
  if (isign == 0) then
    ! Pour la factorisation
    call jmfact(n,fact,100,    0,nfact)
    call jmfact(m,fact,100,nfact,mfact)
    call jmfact(l,fact,100,mfact,lfact)
    table(0:lfact-1) = fact(0:lfact-1)
    ! Pour les sinus et cosinus
    call jmtable(table,ntable,100+0,      n)
    call jmtable(table,ntable,100+2*n,    m)
    call jmtable(table,ntable,100+2*(n+m),l)
    return
  else
    nfact = nint(table(0))
    mfact = nint(table(nfact)) + nfact
    lfact = nint(table(mfact)) + mfact
    fact(0:lfact-1) = nint(table(0:lfact-1))
  end if

  ! Gestion de work
  !nwork = 4*n*m*l
  !nwork = 512*max(n,m,l)
  call jmgetnwork(nwork,512*max(n,m,l),4*max(n,m,l))

  ! On fait les T.F. sur la troisieme dimension en tronconnant sur la premiere
  ! et la deuxieme
  debut = .true.
  fini  = .false.
  do while (.not.fini)

    ! Tronconnage
    ! Note : on met npair a .true. car il n'y a pas de restriction dans ce cas
    call jmdecoup3(n,m,4*l,nwork,debut,.true.,ideb,ifin,jdeb,jfin, &
    & nmtemp,nwork_temp,fini)
    debut = .false.

    ! On copie le tableau d'entree dans le tableau de travail
    ! On en profite pour premultiplier et pour tenir compte du signe
    ! On prend garde a la gestion des extremites
    do k = 0,l-1
      iwork = 0
      do j = jdeb,jfin
        i1 = 0
        i2 = n-1
        if (j == jdeb) i1 = ideb
        if (j == jfin) i2 = ifin
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = i1,i2
          work(             iwork+k*nmtemp) =       scale*x(2*i  ,j,k)
          work(nwork_temp/4+iwork+k*nmtemp) = isign*scale*x(2*i+1,j,k)
          iwork = iwork+1
        end do
      end do
    end do

    ! On fait les T.F. sur la troisieme dimension
    ioff = 0
    call jmccm1d(nmtemp,l,fact,100,mfact,table,ntable,100+2*(n+m), &
    & work,nwork_temp,ioff)

    ! On recopie dans le tableau d'arrivee
    do k = 0,l-1
      iwork = 0
      do j = jdeb,jfin
        i1 = 0
        i2 = n-1
        if (j == jdeb) i1 = ideb
        if (j == jfin) i2 = ifin
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = i1,i2
          y(2*i  ,j,k) = work(ioff             +iwork+k*nmtemp)
          y(2*i+1,j,k) = work(ioff+nwork_temp/4+iwork+k*nmtemp)
          iwork = iwork+1
        end do
      end do
    end do

  end do

  ! On fait les T.F. sur la deuxieme dimension en tronconnant sur la premiere
  ! et la troisieme
  debut = .true.
  fini  = .false.
  do while (.not.fini)

    ! Tronconnage
    call jmdecoup3(n,l,4*m,nwork,debut,.true.,ideb,ifin,kdeb,kfin, &
    & nltemp,nwork_temp,fini)
    debut = .false.

    ! On copie le tableau d'entree dans le tableau de travail
    ! On prend garde a la gestion des extremites
    do j = 0,m-1
      iwork = 0
      do k = kdeb,kfin
        i1 = 0
        i2 = n-1
        if (k == kdeb) i1 = ideb
        if (k == kfin) i2 = ifin
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = i1,i2
          work(             iwork+j*nltemp) = y(2*i  ,j,k)
          work(nwork_temp/4+iwork+j*nltemp) = y(2*i+1,j,k)
          iwork = iwork+1
        end do
      end do
    end do

    ! On fait les T.F. sur la deuxieme dimension
    ioff = 0
    call jmccm1d(nltemp,m,fact,100,nfact,table,ntable,100+2*n, &
    & work,nwork_temp,ioff)

    ! On recopie dans le tableau d'arrivee
    do j = 0,m-1
      iwork = 0
      do k = kdeb,kfin
        i1 = 0
        i2 = n-1
        if (k == kdeb) i1 = ideb
        if (k == kfin) i2 = ifin
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = i1,i2
          y(2*i  ,j,k) = work(ioff             +iwork+j*nltemp)
          y(2*i+1,j,k) = work(ioff+nwork_temp/4+iwork+j*nltemp)
          iwork = iwork+1
        end do
      end do
    end do

  end do

  ! On fait les T.F. sur la premiere dimension en tronconnant sur la deuxieme
  ! et la troisieme
  debut = .true.
  fini  = .false.
  do while (.not.fini)

    ! Tronconnage
    call jmdecoup3(m,l,4*n,nwork,debut,.true.,jdeb,jfin,kdeb,kfin, &
    & mltemp,nwork_temp,fini)
    debut = .false.

    ! On copie le tableau d'entree dans le tableau de travail
    ! On prend garde a la gestion des extremites
    do i = 0,n-1
      iwork = 0
      do k = kdeb,kfin
        j1 = 0
        j2 = m-1
        if (k == kdeb) j1 = jdeb
        if (k == kfin) j2 = jfin
!dir$ ivdep
!ocl novrec
!cdir nodep
        do j = j1,j2
          work(             iwork+i*mltemp) = y(2*i  ,j,k)
          work(nwork_temp/4+iwork+i*mltemp) = y(2*i+1,j,k)
          iwork = iwork+1
        end do
      end do
    end do

    ! On fait les T.F. sur la premiere dimension
    ioff = 0
    call jmccm1d(mltemp,n,fact,100,0,table,ntable,100+0, &
    & work,nwork_temp,ioff)

    ! On recopie dans le tableau d'arrivee en tenant compte du signe
    do i = 0,n-1
      iwork = 0
      do k = kdeb,kfin
        j1 = 0
        j2 = m-1
        if (k == kdeb) j1 = jdeb
        if (k == kfin) j2 = jfin
!dir$ ivdep
!ocl novrec
!cdir nodep
        do j = j1,j2
          y(2*i  ,j,k) =       work(ioff             +iwork+i*mltemp)
          y(2*i+1,j,k) = isign*work(ioff+nwork_temp/4+iwork+i*mltemp)
          iwork = iwork+1
        end do
      end do
    end do

  end do

end subroutine ccfft3d
