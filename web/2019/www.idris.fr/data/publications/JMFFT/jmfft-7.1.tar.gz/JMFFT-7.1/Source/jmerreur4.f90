! $Header: /home/teuler/cvsroot/lib/jmerreur4.f90,v 6.1 1999/10/22 08:35:19 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine jmerreur4(nomsp,code,var1,var2,var3,var4)

  implicit none

  ! Arguments
  character(len=*), intent(in) :: nomsp
  integer, intent(in) :: code
  integer, intent(in) :: var1, var2, var3,var4

  ! Variables locales
  logical :: arret
  character(len=80) :: message

  call jmgeterreur(arret)
  if (arret) then
    call jmgetmessage(code,message)
    print *,'JMFFT Erreur dans ',trim(nomsp),' : ',trim(message), &
    & ' (',var1,var2,var3,var4,')'
    stop 1
  else
    call jmsetcode(code)
  end if

end subroutine jmerreur4
