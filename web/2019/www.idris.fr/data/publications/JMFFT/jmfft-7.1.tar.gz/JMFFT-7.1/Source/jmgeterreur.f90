! $Header: /home/teuler/cvsroot/lib/jmgeterreur.f90,v 6.1 1999/10/22 08:35:19 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

subroutine jmgeterreur(arret)

  implicit none

  ! Argument
  logical, intent(out) :: arret

  ! Variables locales

  call jmgetseterreur(arret,'g')

end subroutine jmgeterreur
