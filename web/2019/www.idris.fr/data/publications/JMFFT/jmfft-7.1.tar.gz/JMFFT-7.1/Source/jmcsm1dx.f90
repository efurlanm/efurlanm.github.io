! $Header: /home/teuler/cvsroot/lib/jmcsm1dx.f90,v 6.1 1999/10/22 08:35:19 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

! Variante de jmcsm1d ou on fournit x en entree et en sortie
subroutine jmcsm1dx(m,n,n2,p2,n3,p3,n5,p5,table,ntable,itable,work,nwork,x,inc,jump)

  implicit none

  ! Arguments
  integer, intent(in) :: m, n, n2, p2, n3, p3, n5, p5
  integer, intent(in) :: ntable,itable
  real(kind=8), intent(in), dimension(0:ntable-1) :: table
  integer, intent(in) :: nwork
  real(kind=8), intent(inout), dimension(0:nwork-1) :: work
  integer, intent(in) :: inc, jump
  real(kind=8), intent(inout), dimension(0:m*(n+2)-1) :: x

  ! Variables locales
  integer :: i, j
  real(kind=8) :: t, u, v, w, tt, uu, vv, ww
  real(kind=8) :: c, s
  integer :: is, it
  integer :: ioff
  character(len=*), parameter :: nomsp = 'JMCSM1DX'

  ! On doit faire m T.F. complexes -> reelles de longueur n
  ! Si m est pair
  if (mod(m,2) == 0) then

    ! On distribue

    if (m/2 >= 16 .or. n/2 < 8) then

      do i = 0,n/2
!dir$ ivdep
!ocl novrec
        do j = 0,m/2-1
          it = n-i
          if (i == 0) it = 0
          t = x(inc*(2*i  )+jump*(j    ))
          u = x(inc*(2*i+1)+jump*(j    ))
          v = x(inc*(2*i  )+jump*(j+m/2))
          w = x(inc*(2*i+1)+jump*(j+m/2))
          work(         i*m/2+j) = (t-w)
          work(nwork/4+ i*m/2+j) = (u+v)
          work(        it*m/2+j) = (t+w)
          work(nwork/4+it*m/2+j) = (v-u)
        end do
      end do

    else

      do j = 0,m/2-1
!dir$ ivdep
!ocl novrec
        do i = 0,n/2
          it = n-i
          if (i == 0) it = 0
          t = x(inc*(2*i  )+jump*(j    ))
          u = x(inc*(2*i+1)+jump*(j    ))
          v = x(inc*(2*i  )+jump*(j+m/2))
          w = x(inc*(2*i+1)+jump*(j+m/2))
          work(         i*m/2+j) = (t-w)
          work(nwork/4+ i*m/2+j) = (u+v)
          work(        it*m/2+j) = (t+w)
          work(nwork/4+it*m/2+j) = (v-u)
        end do
      end do

    end if

    ! On fait m/2 t.f. complexes -> complexes de longueur n
    ioff = 0
    call jmccm1d(m/2,n,n2,p2,n3,p3,n5,p5,table,ntable,itable,work,nwork,ioff)

    ! On reconstitue

    if (m/2 >= 16 .or. n < 8) then

      do i = 0,n-1
!dir$ ivdep
!ocl novrec
        do j = 0,m/2-1
          x(jump*(j    )+inc*i) = work(ioff        +i*m/2+j)
          x(jump*(j+m/2)+inc*i) = work(ioff+nwork/4+i*m/2+j)
        end do
      end do

    else

      do j = 0,m/2-1
!dir$ ivdep
!ocl novrec
        do i = 0,n-1
          x(jump*(j    )+inc*i) = work(ioff        +i*m/2+j)
          x(jump*(j+m/2)+inc*i) = work(ioff+nwork/4+i*m/2+j)
        end do
      end do

    end if

  ! Si m n'est pas pair mais que n l'est
  else if (mod(n,2) == 0) then

    ! On distribue

    if (m >= 16 .or. n/2 < 8) then

      do i = 0,n/2-1
!dir$ ivdep
!ocl novrec
        do j = 0,m-1
          ! Note : Signe - sur les parties imaginaires pour inversion
          t =  x((2*i)  *inc+j*jump)
          u = -x((2*i+1)*inc+j*jump)
          v =  x((2*(n/2-i)  )*inc+j*jump)
          w = -x((2*(n/2-i)+1)*inc+j*jump)
          c = table(i)
          s = table(i+n)
          tt = (t+v)/2
          uu = (u-w)/2
          vv = (c*(t-v)+s*(u+w))/2
          ww = (c*(u+w)-s*(t-v))/2
          ! Note : le facteur 2 et le signe - viennent de l'inversion Fourier
          work(        m*i+j) =  2*(tt-ww)
          work(nwork/4+m*i+j) = -2*(uu+vv)
        end do
      end do

    else

      do j = 0,m-1
!dir$ ivdep
!ocl novrec
        do i = 0,n/2-1
          ! Note : Signe - sur les parties imaginaires pour inversion
          t =  x((2*i)  *inc+j*jump)
          u = -x((2*i+1)*inc+j*jump)
          v =  x((2*(n/2-i)  )*inc+j*jump)
          w = -x((2*(n/2-i)+1)*inc+j*jump)
          c = table(i)
          s = table(i+n)
          tt = (t+v)/2
          uu = (u-w)/2
          vv = (c*(t-v)+s*(u+w))/2
          ww = (c*(u+w)-s*(t-v))/2
          ! Note : le facteur 2 et le signe - viennent de l'inversion Fourier
          work(        m*i+j) =  2*(tt-ww)
          work(nwork/4+m*i+j) = -2*(uu+vv)
        end do
      end do

    end if

    ! On fait m t.f. complexes de taille n/2
    ioff = 0
    call jmccm1d(m,n,n2/2,p2-1,n3,p3,n5,p5,table,ntable,itable,work,nwork,ioff)

    ! On reconstitue

    if (m >= 16 .or. n/2 < 8) then

      do i = 0, n/2-1
!dir$ ivdep
!ocl novrec
        do j = 0, m-1
          ! Note : le signe - vient de l'inversion
          x(inc*(2*i  )+jump*j) =  work(ioff        +m*i+j)
          x(inc*(2*i+1)+jump*j) = -work(ioff+nwork/4+m*i+j)
        end do
      end do

    else

!dir$ ivdep
      do j = 0, m-1
!ocl novrec
        do i = 0, n/2-1
          ! Note : le signe - vient de l'inversion
          x(inc*(2*i  )+jump*j) =  work(ioff        +m*i+j)
          x(inc*(2*i+1)+jump*j) = -work(ioff+nwork/4+m*i+j)
        end do
      end do

    end if

  ! Sinon
  else

    call jmerreur2(nomsp,22,m,n)

  end if

end subroutine jmcsm1dx
