! $Header: /home/teuler/cvsroot/lib/jmscm1dx.f90,v 6.1 1999/10/22 08:35:19 teuler Exp $
! JMFFTLIB : A library of portable fourier transform subroutines
!            emulating Cray SciLib
! Author   : Jean-Marie Teuler, CNRS-IDRIS (teuler@idris.fr)
!
! Permission is granted to copy and distribute this file or modified
! versions of this file for no fee, provided the copyright notice and
! this permission notice are preserved on all copies.

! Variante de jmscm1d ou on fournit x en entree et en sortie
subroutine jmscm1dx(m,n,n2,p2,n3,p3,n5,p5,table,ntable,itable,work,nwork,x,inc,jump)

  implicit none

  ! Arguments
  integer, intent(in) :: m, n, n2, p2, n3, p3, n5, p5
  integer, intent(in) :: ntable,itable
  real(kind=8), intent(in), dimension(0:ntable-1) :: table
  integer, intent(in) :: nwork
  real(kind=8), intent(inout), dimension(0:nwork-1) :: work
  integer, intent(in) :: inc, jump
  real(kind=8), intent(inout), dimension(0:m*(n+2)-1) :: x

  ! Variables locales
  integer :: i, j
  real(kind=8) :: t, u, v, w
  real(kind=8) :: c, s
  integer :: is, it
  integer :: ioff
  character(len=*), parameter :: nomsp = 'JMSCM1DX'

  ! On doit faire m T.F. reelles de longueur n
  ! Si m est pair
  if (mod(m,2) == 0) then

    ! On distribue
    if (m/2 >= 16 .or. n < 8) then

      do i = 0,n-1
!dir$ ivdep
!ocl novrec
!cdir nodep
        do j = 0,m/2-1
          work(        i*m/2+j) = x(i*inc+(j)    *jump)
          work(nwork/4+i*m/2+j) = x(i*inc+(j+m/2)*jump)
        end do
      end do

    else

      do j = 0,m/2-1
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = 0,n-1
          work(        i*m/2+j) = x(i*inc+(j)    *jump)
          work(nwork/4+i*m/2+j) = x(i*inc+(j+m/2)*jump)
        end do
      end do

    end if

    ! On fait m/2 t.f. complexes de longueur n
    ioff = 0
    call jmccm1d(m/2,n,n2,p2,n3,p3,n5,p5,table,ntable,itable,work,nwork,ioff)

    ! On regenere le resultat
    if (m/2 >= 16 .or. n/2 < 8) then

      do i = 0,n/2
!dir$ ivdep
!ocl novrec
!cdir nodep
        do j = 0,m/2-1
          it = n-i
          if (i == 0) it = 0
          t = work(ioff        + i*m/2+j)
          u = work(ioff+nwork/4+ i*m/2+j)
          v = work(ioff        +it*m/2+j)
          w = work(ioff+nwork/4+it*m/2+j)
          x((2*i)  *inc+(j)    *jump) =  (t+v)/2
          x((2*i+1)*inc+(j)    *jump) = -(u-w)/2
          x((2*i)  *inc+(j+m/2)*jump) =  (u+w)/2
          x((2*i+1)*inc+(j+m/2)*jump) = -(v-t)/2
        end do
      end do

    else

      do j = 0,m/2-1
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = 0,n/2
          it = n-i
          if (i == 0) it = 0
          t = work(ioff        + i*m/2+j)
          u = work(ioff+nwork/4+ i*m/2+j)
          v = work(ioff        +it*m/2+j)
          w = work(ioff+nwork/4+it*m/2+j)
          x((2*i)  *inc+(j)    *jump) =  (t+v)/2
          x((2*i+1)*inc+(j)    *jump) = -(u-w)/2
          x((2*i)  *inc+(j+m/2)*jump) =  (u+w)/2
          x((2*i+1)*inc+(j+m/2)*jump) = -(v-t)/2
        end do
      end do

    end if

  ! Si m n'est pas pair mais que n l'est
  else if (mod(n,2) == 0) then

    ! On distribue les indices pairs et impairs selon n

    if (m >= 16 .or. n/2 < 8) then

      do i = 0, n/2-1
!dir$ ivdep
!ocl novrec
!cdir nodep
        do j = 0, m-1
          work(m*(      i)+j) = x(inc*(2*i  )+jump*j)
          work(m*(n/2+1+i)+j) = x(inc*(2*i+1)+jump*j)
        end do
      end do

    else

      do j = 0, m-1
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = 0, n/2-1
          work(m*(      i)+j) = x(inc*(2*i  )+jump*j)
          work(m*(n/2+1+i)+j) = x(inc*(2*i+1)+jump*j)
        end do
      end do

    end if

    ! On fait m t.f. complexes de taille n/2
    ioff = 0
    call jmccm1d(m,n,n2/2,p2-1,n3,p3,n5,p5,table,ntable,itable,work,nwork,ioff)

    ! Maintenant, il faut reconstituer la t.f. reelle

    if (m >= 16 .or. n/2 < 8) then

      do i = 0,n/2
!dir$ ivdep
!ocl novrec
!cdir nodep
        do j = 0,m-1
          is = i
          it = n/2-i
          if (i == 0 .or. i == n/2) then
            is = 0
            it = 0
          end if
          t = work(ioff        +is*m+j)
          u = work(ioff+nwork/4+is*m+j)
          v = work(ioff        +it*m+j)
          w = work(ioff+nwork/4+it*m+j)
          c = table(i)
          s = table(i+n)
          x((2*i  )*inc+j*jump) =  ((t+v)/2 + c*(u+w)/2 - s*(v-t)/2)
          x((2*i+1)*inc+j*jump) = -((u-w)/2 + c*(v-t)/2 + s*(u+w)/2)
        end do
      end do

    else

      do j = 0,m-1
!dir$ ivdep
!ocl novrec
!cdir nodep
        do i = 0,n/2
          is = i
          it = n/2-i
          if (i == 0 .or. i == n/2) then
            is = 0
            it = 0
          end if
          t = work(ioff        +is*m+j)
          u = work(ioff+nwork/4+is*m+j)
          v = work(ioff        +it*m+j)
          w = work(ioff+nwork/4+it*m+j)
          c = table(i)
          s = table(i+n)
          x((2*i  )*inc+j*jump) =  ((t+v)/2 + c*(u+w)/2 - s*(v-t)/2)
          x((2*i+1)*inc+j*jump) = -((u-w)/2 + c*(v-t)/2 + s*(u+w)/2)
        end do
      end do

    end if

  ! Sinon
  else

    call jmerreur2(nomsp,22,m,n)

  end if

end subroutine jmscm1dx
